# Mini project script

This is the exact content a reviewer approves.
