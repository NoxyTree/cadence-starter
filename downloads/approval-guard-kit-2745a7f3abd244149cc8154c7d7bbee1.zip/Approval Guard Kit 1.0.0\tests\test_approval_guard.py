from __future__ import annotations

import json
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

import approval_guard


class ApprovalGuardTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def write(self, relative: str, content: str = "content\n") -> Path:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def test_approve_then_current(self) -> None:
        self.write("script.md")
        approval_guard.approve(self.root, "script", ["script.md"], "Reviewer")
        result = approval_guard.inspect_gate(self.root, "script")
        self.assertEqual(result["status"], "current")

    def test_edit_turns_approval_stale(self) -> None:
        self.write("script.md", "one\n")
        approval_guard.approve(self.root, "script", ["script.md"], "Reviewer")
        self.write("script.md", "two\n")
        self.assertEqual(approval_guard.inspect_gate(self.root, "script")["status"], "stale")

    def test_directory_addition_turns_approval_stale(self) -> None:
        self.write("assets/a.txt")
        approval_guard.approve(self.root, "assets", ["assets"], "Reviewer")
        self.write("assets/b.txt")
        self.assertEqual(approval_guard.inspect_gate(self.root, "assets")["status"], "stale")

    def test_directory_deletion_turns_approval_stale(self) -> None:
        self.write("assets/a.txt")
        removed = self.write("assets/b.txt")
        approval_guard.approve(self.root, "assets", ["assets"], "Reviewer")
        removed.unlink()
        self.assertEqual(approval_guard.inspect_gate(self.root, "assets")["status"], "stale")

    def test_unapproved_gate_is_reported(self) -> None:
        result = approval_guard.inspect_gate(self.root, "release")
        self.assertEqual(result["status"], "unapproved")

    def test_status_uses_recorded_inputs(self) -> None:
        self.write("notes/one.md")
        approval_guard.approve(self.root, "notes", ["notes"], "Reviewer")
        result = approval_guard.inspect_gate(self.root, "notes")
        self.assertEqual(result["inputs"], ["notes"])

    def test_path_outside_root_is_rejected(self) -> None:
        outside = self.root.parent / "outside.txt"
        outside.write_text("outside", encoding="utf-8")
        self.addCleanup(lambda: outside.unlink(missing_ok=True))
        with self.assertRaisesRegex(ValueError, "escapes project root"):
            approval_guard.fingerprint(self.root, [outside])

    def test_state_file_is_not_part_of_directory_fingerprint(self) -> None:
        self.write("script.md")
        approval_guard.approve(self.root, "all", ["."], "Reviewer")
        self.assertEqual(approval_guard.inspect_gate(self.root, "all")["status"], "current")

    def test_multiple_gates_are_listed_in_name_order(self) -> None:
        self.write("a.txt")
        self.write("b.txt")
        approval_guard.approve(self.root, "zeta", ["a.txt"], "Reviewer")
        approval_guard.approve(self.root, "alpha", ["b.txt"], "Reviewer")
        self.assertEqual([item["gate"] for item in approval_guard.list_gates(self.root)], ["alpha", "zeta"])

    def test_require_exit_code_is_zero_when_current(self) -> None:
        self.write("script.md")
        approval_guard.approve(self.root, "script", ["script.md"], "Reviewer")
        with redirect_stdout(StringIO()):
            code = approval_guard.main(["require", "script", "--root", str(self.root)])
        self.assertEqual(code, 0)

    def test_require_exit_code_is_two_when_stale(self) -> None:
        self.write("script.md", "one")
        approval_guard.approve(self.root, "script", ["script.md"], "Reviewer")
        self.write("script.md", "two")
        with redirect_stdout(StringIO()):
            code = approval_guard.main(["require", "script", "--root", str(self.root)])
        self.assertEqual(code, 2)

    def test_json_store_contains_per_file_manifest(self) -> None:
        self.write("script.md", "hello")
        approval_guard.approve(self.root, "script", ["script.md"], "Reviewer")
        data = json.loads((self.root / ".approval-guard" / "approvals.json").read_text(encoding="utf-8"))
        file_record = data["gates"]["script"]["files"][0]
        self.assertEqual(file_record["path"], "script.md")
        self.assertEqual(file_record["bytes"], 5)
        self.assertEqual(len(file_record["sha256"]), 64)

    def test_empty_directory_is_rejected(self) -> None:
        (self.root / "empty").mkdir()
        with self.assertRaisesRegex(ValueError, "No files found"):
            approval_guard.approve(self.root, "empty", ["empty"], "Reviewer")


if __name__ == "__main__":
    unittest.main()
