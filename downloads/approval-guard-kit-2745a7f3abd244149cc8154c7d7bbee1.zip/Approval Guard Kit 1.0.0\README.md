# Approval Guard Kit 1.0.0

Bind a human approval to the exact local files that were reviewed. If a file is edited, added, removed, or renamed, the approval becomes stale and downstream automation can stop.

This is a focused, dependency-free Python kit—not a hosted app, AI service, or subscription.

## What is included

- `approval_guard.py`: the complete standalone source
- named approval gates for scripts, assets, releases, or any other checkpoint
- stable SHA-256 fingerprints for individual files and recursive directories
- a durable per-file manifest in `.approval-guard/approvals.json`
- `status` for humans and JSON output for tools
- `require` with CI-safe exit codes: `0` current, `2` blocked
- project-root path protection and automatic exclusion of state, Git, and cache files
- 13 dependency-free automated tests
- local shell, PowerShell, Python, and GitHub Actions integration recipes
- a small example project

## Requirements

- Python 3.10 or newer
- Windows, macOS, or Linux
- no third-party packages

## Start in one minute

From this folder:

```text
python approval_guard.py approve script script.md --by "Editor"
python approval_guard.py status script
```

Edit `script.md`, then run the status command again:

```text
script: stale — reviewed content changed
```

Block a later command unless approval is current:

```text
python approval_guard.py require script && python render.py
```

On Windows PowerShell:

```powershell
python approval_guard.py require script
if ($LASTEXITCODE -eq 0) { python render.py }
```

## Files and directories

Approve several files together:

```text
python approval_guard.py approve release script.md assets/manifest.json scenes/ --by "Producer"
```

Directory fingerprints are recursive. Adding, deleting, renaming, or editing any contained file invalidates the approval.

## Machine-readable output

```text
python approval_guard.py status release --json
python approval_guard.py list --json
```

The JSON result includes the approved and current fingerprints, reviewer label, approval time, inputs, and a per-file SHA-256 manifest.

## Exit codes

- `approve`: `0` recorded, `2` error
- `status`: `0` current, `1` stale or unapproved, `2` error
- `require`: `0` current, `2` stale, unapproved, or error
- `list`: `0` all current, `1` at least one is not current

## Run the tests

```text
python -m unittest discover -s tests -v
```

## Product boundary

Approval Guard Kit solves one problem: approvals that should expire when local content changes.

It does not provide dependency graphs, next-safe-action resolution, project scaffolding, schemas, templates, command allowlists, or dry-run execution. Those broader workflow features belong to the separate Cadence Starter engine.

## License

The purchase includes a perpetual single-user commercial-use license. You may modify and use the source in your own personal or commercial workflows. You may not redistribute or resell the kit itself. See `LICENSE.txt`.
