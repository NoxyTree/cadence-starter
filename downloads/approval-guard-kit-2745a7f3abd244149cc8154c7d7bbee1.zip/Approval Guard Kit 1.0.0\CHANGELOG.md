# Changelog

## 1.0.0 — 2026-07-18

- First commercial release.
- Added named multi-file and recursive-directory approval gates.
- Added stable SHA-256 manifests and atomic local state writes.
- Added human and JSON status output.
- Added CI-safe `require` command and exit codes.
- Added project-root path protection and state-directory exclusions.
- Added 13 dependency-free tests and integration recipes.
