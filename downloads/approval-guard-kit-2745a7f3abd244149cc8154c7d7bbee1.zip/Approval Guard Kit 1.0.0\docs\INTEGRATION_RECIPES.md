# Integration recipes

## Shell pipeline

```sh
python approval_guard.py require release && ./publish.sh
```

## PowerShell pipeline

```powershell
python approval_guard.py require release
if ($LASTEXITCODE -ne 0) {
    throw "Release approval is missing or stale"
}
python publish.py
```

## Python pipeline

Keep `approval_guard.py` beside your own script:

```python
from pathlib import Path
from approval_guard import inspect_gate

result = inspect_gate(Path.cwd(), "release")
if result["status"] != "current":
    raise SystemExit(f"Blocked: {result['reason']}")

# Safe dependent work begins here.
```

## GitHub Actions

Commit `approval_guard.py` and the approval store if your team intentionally treats the stored fingerprint as repository state:

```yaml
- name: Require current release approval
  run: python approval_guard.py require release

- name: Publish
  if: success()
  run: python publish.py
```

The gate is deterministic and requires no API key. Decide whether reviewer names and timestamps are appropriate to commit in your repository.

## Multiple gates

```text
python approval_guard.py approve sources research/ --by "Research reviewer"
python approval_guard.py approve script script.md --by "Script editor"
python approval_guard.py approve release renders/final.mp4 metadata.json --by "Publisher"
python approval_guard.py list
```

## Custom state location

```text
python approval_guard.py approve script script.md --store workflow/approvals.json --by "Editor"
python approval_guard.py require script --store workflow/approvals.json
```

The state file must remain inside the project root. It is automatically excluded when a parent directory is fingerprinted.
