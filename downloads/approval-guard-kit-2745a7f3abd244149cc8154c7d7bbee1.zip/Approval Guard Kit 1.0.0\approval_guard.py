from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Sequence


VERSION = "1.0.0"
DEFAULT_STORE = ".approval-guard/approvals.json"
IGNORED_DIRECTORY_NAMES = {".git", ".approval-guard", "__pycache__"}


def project_path(root: Path, value: str | Path) -> Path:
    root = root.resolve()
    candidate = (root / value).resolve() if not Path(value).is_absolute() else Path(value).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"Path escapes project root: {value}") from exc
    return candidate


def store_path(root: Path, value: str | Path = DEFAULT_STORE) -> Path:
    return project_path(root, value)


def read_store(root: Path, store: str | Path = DEFAULT_STORE) -> dict[str, Any]:
    path = store_path(root, store)
    if not path.exists():
        return {"version": "1", "gates": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Could not read approval store: {path}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("gates"), dict):
        raise ValueError(f"Approval store has an invalid structure: {path}")
    return data


def write_store(root: Path, data: dict[str, Any], store: str | Path = DEFAULT_STORE) -> Path:
    path = store_path(root, store)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)
    return path


def _is_ignored(path: Path, root: Path, state_path: Path) -> bool:
    if path.resolve() == state_path.resolve():
        return True
    relative = path.resolve().relative_to(root.resolve())
    return any(part in IGNORED_DIRECTORY_NAMES for part in relative.parts)


def collect_files(
    root: Path,
    inputs: Sequence[str | Path],
    store: str | Path = DEFAULT_STORE,
) -> list[tuple[str, Path]]:
    root = root.resolve()
    state_path = store_path(root, store)
    files: dict[str, Path] = {}

    for raw in inputs:
        candidate = project_path(root, raw)
        if not candidate.exists():
            raise ValueError(f"Input does not exist: {raw}")
        if candidate.is_file():
            candidates = [candidate]
        elif candidate.is_dir():
            candidates = [path for path in candidate.rglob("*") if path.is_file()]
        else:
            raise ValueError(f"Input is not a regular file or directory: {raw}")

        for path in candidates:
            if _is_ignored(path, root, state_path):
                continue
            relative = path.resolve().relative_to(root).as_posix()
            files[relative] = path.resolve()

    if not files:
        raise ValueError("No files found in the supplied inputs")
    return sorted(files.items(), key=lambda item: item[0])


def fingerprint(
    root: Path,
    inputs: Sequence[str | Path],
    store: str | Path = DEFAULT_STORE,
) -> tuple[str, list[dict[str, Any]]]:
    digest = sha256()
    manifest: list[dict[str, Any]] = []

    for relative, path in collect_files(root, inputs, store):
        content = path.read_bytes()
        content_hash = sha256(content).hexdigest()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(content_hash.encode("ascii"))
        digest.update(b"\n")
        manifest.append({"path": relative, "bytes": len(content), "sha256": content_hash})

    return digest.hexdigest(), manifest


def approve(
    root: Path,
    gate: str,
    inputs: Sequence[str | Path],
    approved_by: str,
    store: str | Path = DEFAULT_STORE,
) -> dict[str, Any]:
    gate = gate.strip()
    approved_by = approved_by.strip()
    if not gate:
        raise ValueError("Gate name cannot be empty")
    if not approved_by:
        raise ValueError("Approver name cannot be empty")

    current_hash, manifest = fingerprint(root, inputs, store)
    data = read_store(root, store)
    record = {
        "gate": gate,
        "approved_by": approved_by,
        "approved_at": datetime.now(timezone.utc).isoformat(),
        "inputs": [str(value) for value in inputs],
        "fingerprint": current_hash,
        "files": manifest,
    }
    data["gates"][gate] = record
    write_store(root, data, store)
    return record


def inspect_gate(
    root: Path,
    gate: str,
    inputs: Sequence[str | Path] | None = None,
    store: str | Path = DEFAULT_STORE,
) -> dict[str, Any]:
    data = read_store(root, store)
    record = data["gates"].get(gate)
    if record is None:
        return {"gate": gate, "status": "unapproved", "reason": "no approval is recorded"}

    selected_inputs = list(inputs) if inputs else list(record.get("inputs") or [])
    if not selected_inputs:
        return {"gate": gate, "status": "error", "reason": "approval record has no inputs"}

    try:
        current_hash, manifest = fingerprint(root, selected_inputs, store)
    except ValueError as exc:
        return {
            "gate": gate,
            "status": "stale",
            "reason": str(exc),
            "approved_fingerprint": record.get("fingerprint"),
        }

    approved_hash = record.get("fingerprint")
    is_current = bool(approved_hash and approved_hash == current_hash)
    return {
        "gate": gate,
        "status": "current" if is_current else "stale",
        "reason": "fingerprint matches" if is_current else "reviewed content changed",
        "approved_by": record.get("approved_by"),
        "approved_at": record.get("approved_at"),
        "approved_fingerprint": approved_hash,
        "current_fingerprint": current_hash,
        "inputs": selected_inputs,
        "files": manifest,
    }


def list_gates(root: Path, store: str | Path = DEFAULT_STORE) -> list[dict[str, Any]]:
    data = read_store(root, store)
    return [inspect_gate(root, gate, store=store) for gate in sorted(data["gates"])]


def _add_common(parser: argparse.ArgumentParser, *, paths: bool) -> None:
    parser.add_argument("gate", help="Named approval gate, for example script or release")
    if paths:
        parser.add_argument("paths", nargs="*", help="Project-relative files or directories")
    parser.add_argument("--root", default=".", help="Project root (default: current directory)")
    parser.add_argument("--store", default=DEFAULT_STORE, help=f"State file (default: {DEFAULT_STORE})")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="approval_guard",
        description="Bind human approvals to the exact local files that were reviewed.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    commands = parser.add_subparsers(dest="command", required=True)

    approve_parser = commands.add_parser("approve", help="Record approval for files or directories")
    _add_common(approve_parser, paths=True)
    approve_parser.add_argument("--by", default="local-reviewer", help="Reviewer label")

    status_parser = commands.add_parser("status", help="Report whether an approval is still current")
    _add_common(status_parser, paths=True)

    require_parser = commands.add_parser("require", help="Exit 0 only when an approval is current")
    _add_common(require_parser, paths=True)

    list_parser = commands.add_parser("list", help="List all recorded gates and their current state")
    list_parser.add_argument("--root", default=".", help="Project root (default: current directory)")
    list_parser.add_argument("--store", default=DEFAULT_STORE, help=f"State file (default: {DEFAULT_STORE})")
    list_parser.add_argument("--json", action="store_true", help="Print machine-readable JSON")
    return parser


def _print_result(result: dict[str, Any], as_json: bool) -> None:
    if as_json:
        print(json.dumps(result, indent=2, sort_keys=True))
        return
    print(f"{result['gate']}: {result['status']} — {result['reason']}")
    if result.get("approved_by"):
        print(f"approved by: {result['approved_by']}")


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()

    try:
        if args.command == "approve":
            if not args.paths:
                parser.error("approve requires at least one file or directory")
            record = approve(root, args.gate, args.paths, args.by, args.store)
            result = {
                "gate": args.gate,
                "status": "current",
                "reason": f"approved {len(record['files'])} file(s)",
                **record,
            }
            _print_result(result, args.json)
            return 0

        if args.command in {"status", "require"}:
            result = inspect_gate(root, args.gate, args.paths or None, args.store)
            _print_result(result, args.json)
            if result["status"] == "current":
                return 0
            return 2 if args.command == "require" else 1

        if args.command == "list":
            results = list_gates(root, args.store)
            if args.json:
                print(json.dumps(results, indent=2, sort_keys=True))
            elif not results:
                print("No approval gates recorded.")
            else:
                for result in results:
                    print(f"{result['gate']}: {result['status']} — {result['reason']}")
            return 0 if all(item["status"] == "current" for item in results) else 1

    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
